﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FOOD.SOMATO.BL.Logger;
using System.Net;
using FOOD.SOMATO.BL.Utilities;
using System.Configuration;

namespace FOOD.SOMATO.Filters
{
    public class CustomErrorHandler : FilterAttribute, IExceptionFilter
    {
        public ILogger Logger { get; set; }
        public CustomErrorHandler()
        {
            this.Logger = new WindowsEventLogger();
        }

        public void OnException(ExceptionContext filterContext)
        {
            string SourceSystem = ConfigurationManager.AppSettings["SourceSystem"];

            if (filterContext.ExceptionHandled)
                return;

            var statusCode = (int)HttpStatusCode.InternalServerError;
            var httpException = filterContext.Exception as HttpException;
            if (httpException != null)
            {
                statusCode = httpException.GetHttpCode();
            }
            else if (filterContext.Exception is UnauthorizedAccessException)
            {
                statusCode = (int)HttpStatusCode.Forbidden;
            }
            Logger.WriteException(filterContext.Exception);

            var result = CreateActionResult(filterContext, statusCode);
            filterContext.Result = result;

            filterContext.ExceptionHandled = true;
            filterContext.HttpContext.Response.Clear();

            filterContext.HttpContext.Response.StatusCode = 200;
            filterContext.HttpContext.Response.TrySkipIisCustomErrors = true;

        }

        
        private ActionResult CreateActionResult(ExceptionContext filterContext, int statusCode)
        {
            var ctx = new ControllerContext(filterContext.RequestContext, filterContext.Controller);
            var statusCodeName = ((HttpStatusCode)statusCode).ToString();
            var viewName = SelectFirstView(ctx, String.Format("~/Views/Shared/{0}.cshtml", statusCodeName), "~/Views/Shared/Error.cshtml", statusCodeName, "Error");
            var controllerName = (string)filterContext.RouteData.Values["controller"];
            var actionName = (string)filterContext.RouteData.Values["action"];
            HandleErrorInfo model = null;
            string specificErrorMsg = Convert.ToString(System.Web.Configuration.WebConfigurationManager.AppSettings[controllerName + "." + actionName]);
            string genericErrorMsg = string.Empty;

            if (actionName == ConstantHelper.Refresh)
            {
                genericErrorMsg = ConstantHelper.RefreshUnsuccessmsg;
            }
            else
            {
                genericErrorMsg = ConstantHelper.GenericErrorMsg;
            }

            if (!String.IsNullOrEmpty(specificErrorMsg))
            {
                model = new HandleErrorInfo(new HttpException(statusCode, specificErrorMsg), controllerName, actionName);
            }
            else if (!String.IsNullOrEmpty(genericErrorMsg))
            {
                model = new HandleErrorInfo(new HttpException(statusCode, genericErrorMsg), controllerName, actionName);
            }
            else
            {
                model = new HandleErrorInfo(filterContext.Exception, controllerName, actionName);
            }
            var result = new ViewResult
            {
                ViewName = viewName,
                ViewData = new ViewDataDictionary<HandleErrorInfo>(model),
            };
            result.ViewBag.StatusCode = statusCode;
            return result;
        }
        
        private string SelectFirstView(ControllerContext ctx, params string[] viewNames)
        {
            return viewNames.First(view => ViewExists(ctx, view));
        }

        
        private bool ViewExists(ControllerContext ctx, string name)
        {
            var result = ViewEngines.Engines.FindView(ctx, name, null);
            return result.View != null;
        }
    }
}