using System.Web.Mvc;
using FOOD.SOMATO.BL.Logger;
using Unity;
using Unity.Mvc5;

namespace FOOD.SOMATO
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
			var container = new UnityContainer();
            container.RegisterType<ILogger, WindowsEventLogger>();
            DependencyResolver.SetResolver(new UnityDependencyResolver(container));
        }
    }
}