﻿using System.Web;
using System.Web.Mvc;

namespace FOOD.SOMATO
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
