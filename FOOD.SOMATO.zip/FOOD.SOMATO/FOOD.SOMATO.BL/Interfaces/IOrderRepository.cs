﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FoodDelivery.Models;
using FOOD.SOMATO.BL.Interfaces;

namespace FOOD.SOMATO.BL.Interfaces
{
    public interface IOrderRepository : IRepository<Order>
    {
        
    }
}
