﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FOOD.SOMATO.BL.Utilities
{
    public static class ConstantHelper
    {
        public const string RefreshMsg = "RefreshMsg";
        public const string RefreshUnsuccessmsg = "RefreshUnsuccessmsg";
        public const string GenericErrorMsg = "GenericErrorMsg";

        public const string Refresh = "Refresh";
    }
}
